﻿using Microsoft.AspNetCore.Mvc;

namespace Projeto_Cadastro_MVC.Controllers //onde está
{
    public class FuncionarioController : Controller
    {
        public IActionResult Index() // herda o comportamento de controller
        {
            return View();
        }
    }
}
